<?php
	$template_info['name'] = 'Bootstrap'; // do not use the _ character. use - instead
	$template_info['desc'] = 'Simple and flexible HTML, CSS, and Javascript for popular user interface components and interactions. Details can be found at the website: http://twitter.github.com/bootstrap/';
	$template_info['author'] = 'Eric (Yankidank) Heikkinen';
	$template_info['support'] = 'http://pligg.com/';
	$template_info['version'] = '3.0.0.1';
	$template_info['designed_for_pligg_version'] = '2.0.0';
	
//	$template_info['homepage_url'] = 'http://pligg.com/downloads/template/bootstrap/';
//	$template_info['update_url'] = 'http://pligg.com/downloads/template/bootstrap/version/';
	
?>
