<?php
$widget['widget_title'] = "Admin Panel Tools";
$widget['widget_has_settings'] = 0;
$widget['widget_shrink_icon'] = 1;
$widget['widget_uninstall_icon'] = 0;
$widget['name'] = 'Admin Panel Tools';
$widget['desc'] = 'This module contians links to useful tools for Administrators. Examples include: Delete template cache, Optimize Database, and Backup site.';
$widget['version'] = 0.1;

?>
