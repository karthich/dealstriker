<?php
$widget['widget_title'] = "Pligg CMS";
$widget['widget_has_settings'] = 0;
$widget['widget_shrink_icon'] = 1;
$widget['widget_uninstall_icon'] = 1;
$widget['name'] = 'Pligg CMS';
$widget['desc'] = 'This widget provides links to Pligg.com that you might find useful.';
$widget['version'] = 1.0;

?>
