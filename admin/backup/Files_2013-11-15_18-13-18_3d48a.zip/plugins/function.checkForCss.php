<?php
	function tpl_function_checkForCss($params, &$smarty)
	{
		check_for_css();
	}
?>