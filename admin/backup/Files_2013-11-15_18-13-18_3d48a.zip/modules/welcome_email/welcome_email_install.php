<?php
	$module_info['name'] = 'Send Welcome Email';
	$module_info['desc'] = 'Sends a welcome email to new users when they register an account.';
	$module_info['version'] = 0.2;
?>