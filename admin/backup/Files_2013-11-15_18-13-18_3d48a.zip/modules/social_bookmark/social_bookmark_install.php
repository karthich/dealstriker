<?php
	$module_info['name'] = 'Social Bookmark';
	$module_info['desc'] = 'Adds social bookmarking links in a popup menu located in the story footer area.';
	$module_info['version'] = 2.0;
?>
