<?php
	$module_info['name'] = 'Admin Modify Language';
	$module_info['desc'] = 'Lets Admin users modify the default language file from a web interface.';
	$module_info['version'] = 2.0;
	$module_info['settings_url'] = '../module.php?module=admin_language';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/admin-modify-language/';
	$module_info['update_url'] = 'http://pligg.com/downloads/module/admin-modify-language/version/';

?>
