<?php
	$module_info['name'] = 'Sidebar Stories';
	$module_info['desc'] = 'Displays the latest published or new stories in the sidebar.';
	$module_info['version'] = 2.0;
?>
