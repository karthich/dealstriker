<?php
	$module_info['name'] = 'Captcha';
	$module_info['desc'] = 'Allows you to add CAPTCHA fields to the register, comment or story submission fields to prevent spammers from automated posting.';
	$module_info['version'] = 2.1;
	$module_info['settings_url'] = '../module.php?module=captcha';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/captcha/';
	$module_info['update_url'] = 'http://pligg.com/downloads/module/captcha/version/';

?>

