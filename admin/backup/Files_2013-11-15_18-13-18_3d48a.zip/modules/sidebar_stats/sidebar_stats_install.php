<?php
	$module_info['name'] = 'Sidebar Statistics';
	$module_info['desc'] = 'Inserts a sidebar "widget" containing statistics from your site, including: newest member, total members, total stories, total comments, etc.';
	$module_info['version'] = 2.0;
	$module_info['update_url'] = 'http://pligg.com/downloads/module/sidebar-statistics/version/';
	$module_info['homepage_url'] = 'http://pligg.com/downloads/module/sidebar-statistics/';
	
?>
