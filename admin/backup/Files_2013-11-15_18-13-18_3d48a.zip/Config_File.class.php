<?php

require_once(TEMPLATE_LITE_DIR . "class.config.php");

class Config_File extends config{

    function Config_File($config_path = NULL)
    {
    }
}

?>