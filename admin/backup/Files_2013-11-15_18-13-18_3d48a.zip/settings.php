<?php
$my_base_url = 'http://localhost';
$my_pligg_base = '';
$dblang = 'en';
define('table_prefix', 'pligg_');
$language = 'english';
include_once mnminclude.'settings_from_db.php';
?>